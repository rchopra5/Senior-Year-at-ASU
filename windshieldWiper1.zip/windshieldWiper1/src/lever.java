
public class lever {

	private String leverPosition;
	
	public lever(String lev)
	{
		this.leverPosition=lev;
	}
	
	// Get the current position of the lever.
	public String getLeverPosition() {
	return leverPosition;
	}
	// Set the lever position.
	public void setLeverPosition(String leverPosition) {
	this.leverPosition = leverPosition;
	}
	
	
		
}

