public class LeverErrorException extends Exception {
public LeverErrorException() {
super();
}
public LeverErrorException(String error) {
super(error);
}
}