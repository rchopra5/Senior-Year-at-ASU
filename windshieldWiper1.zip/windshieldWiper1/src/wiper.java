
public class wiper {
// State variables.
private int wiperSpeed;

public wiper(int wiperSpeed) {
this.wiperSpeed = wiperSpeed;

}
// Get the current wiper speed.
public int getWiperSpeed() {
return wiperSpeed;
}
// Set the wiper speed.
public void setWiperSpeed(int wiperSpeed) {
this.wiperSpeed = wiperSpeed;
}

}
